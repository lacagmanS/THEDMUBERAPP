package com.example.dmuber

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.dmuber.R

class Testactivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_test)
        supportFragmentManager.beginTransaction()
            .replace(R.id.container, MapsFragment())
            .commit()
    }
}
