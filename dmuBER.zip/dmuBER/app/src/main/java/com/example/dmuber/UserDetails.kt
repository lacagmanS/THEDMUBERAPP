package com.example.dmuber
data class UserDetails(
    val fullName: String,
    val userName: String,
    val email: String,
    val phoneNumber: String,
    val customerId: String
)
